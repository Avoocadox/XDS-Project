package br.com.gabriel.projetoxds.model

class Login {
    //Classe criada inicialmente para consumação da API
    var username = ""
    var senha = ""
    override fun toString(): String {
        return "Login(login='$username', senha='$senha')"
    }


}