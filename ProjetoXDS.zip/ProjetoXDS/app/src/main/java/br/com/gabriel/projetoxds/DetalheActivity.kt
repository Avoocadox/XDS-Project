package br.com.gabriel.projetoxds

import android.content.Intent
import android.graphics.drawable.Drawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf

class DetalheActivity : AppCompatActivity() {
    lateinit var imgPizza : ImageView
    lateinit var nomePizza : TextView
    lateinit var valorPizza : TextView
    lateinit var ratingPizza : RatingBar
    lateinit var btnTamanhoP : Button
    lateinit var btnTamanhoM : Button
    lateinit var btnTamanhoG : Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhe)
        btnTamanhoP = findViewById(R.id.btnTamanhoP)
        btnTamanhoM = findViewById(R.id.btnTamanhoM)
        btnTamanhoG = findViewById(R.id.btnTamanhoG)
        imgPizza = findViewById(R.id.imgPizzaGenerica)
        nomePizza = findViewById(R.id.TxtNomePizzaGenerica)
        valorPizza = findViewById(R.id.valorPizzaGenerica)
        ratingPizza = findViewById(R.id.RtbPizzaGenerica)
        var pizza = intent.getStringExtra("pizza")
        if(pizza == "4queijos"){
            imgPizza.setImageResource(R.drawable.pizza_4queijos)
            nomePizza.setText(R.string.pizza_de_quatro_queijos)
            valorPizza.text = "R$35,00"
            ratingPizza.rating = 1F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$61,11"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$54,99"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$41,33"
            }
        }
        if(pizza == "toscana"){
            imgPizza.setImageResource(R.drawable.pizza_toscana)
            nomePizza.setText(R.string.pizza_toscana)
            valorPizza.text = "R$39,00"
            ratingPizza.rating = 2F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$48,99"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$45,00"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$39,00"
            }
        }
        if(pizza == "atum"){
            imgPizza.setImageResource(R.drawable.pizza_atum)
            nomePizza.setText(R.string.pizza_de_atum)
            valorPizza.text = "R$36,00"
            ratingPizza.rating = 5F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$46,00"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$40,00"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$36,00"
            }
        }
        if(pizza == "portuguesa"){
            imgPizza.setImageResource(R.drawable.pizza_portuguesa)
            nomePizza.setText(R.string.pizza_de_portuguesa)
            valorPizza.text = "R$45,00"
            ratingPizza.rating = 2F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$56,99"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$50,00"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$45,00"
            }
        }
        if(pizza == "marguerita"){
            imgPizza.setImageResource(R.drawable.pizza_marguerita)
            nomePizza.setText(R.string.pizza_de_marguerita)
            valorPizza.text = "R$40,00"
            ratingPizza.rating = 5F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$53,49"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$45,00"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$40,00"
            }
        }
        if(pizza == "peperoni"){
            imgPizza.setImageResource(R.drawable.pizza_peperoni)
            nomePizza.setText(R.string.pizza_de_peperoni)
            valorPizza.text = "R$41,00"
            ratingPizza.rating = 3F
            btnTamanhoG.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$51,99"
            }
            btnTamanhoM.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
                btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
                valorPizza.text = "R$45,00"
            }
            btnTamanhoP.setOnClickListener {
                btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
                btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
                valorPizza.text = "R$41,00"
            }
        }
        if(pizza == "calabresa"){
            imgPizza.setImageResource(R.drawable.pizza_calabresa)
            nomePizza.setText(R.string.pizza_de_calabresa)
            valorPizza.text = "R$35,00"
            ratingPizza.rating = 4F
        }
        btnTamanhoG.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
            btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
            valorPizza.text = "R$46,00"
        }
        btnTamanhoM.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
            btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
            valorPizza.text = "R$39,00"
        }
        btnTamanhoP.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
            valorPizza.text = "R$33,00"
        }
        if(pizza == "mussarela"){
            imgPizza.setImageResource(R.drawable.pizza_mussarela)
            nomePizza.setText(R.string.pizza_de_mussarela)
            valorPizza.text = "R$33,00"
            ratingPizza.rating = 4F
        }
        btnTamanhoG.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.change_background_button)
            btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
            valorPizza.text = "R$48,00"
        }
        btnTamanhoM.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoM.setBackgroundResource(R.drawable.change_background_button)
            btnTamanhoP.setBackgroundResource(R.drawable.border_rounder_btn)
            valorPizza.text = "R$40,00"
        }
        btnTamanhoP.setOnClickListener {
            btnTamanhoG.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoM.setBackgroundResource(R.drawable.border_rounder_btn)
            btnTamanhoP.setBackgroundResource(R.drawable.change_background_button)
            valorPizza.text = "R$35,00"
        }


    }

    fun btnComprar(view: View) {
        val it = Intent(this, SucessoActivity :: class.java)
        startActivity(it)
    }
}

