package br.com.gabriel.projetoxds.http

import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
//Classe criada para criaçãode Json e manipulação do body
class HttpHelper {
    fun post (json : String) : String{
        //Definir URL do server
        val URL = "https://p3teufi0k9.execute-api.us-east-1.amazonaws.com/v1/signin"

        //Definir cabeçalho
        val headerHttp = MediaType.parse("accept;application/json")

        //Criar o client da requisição
        val client = OkHttpClient()

        //Criar o body da requisição
        val body = RequestBody.create(headerHttp,json)

        //Construir a requisição POST http para o servidor
        var request = Request.Builder().url(URL).post(body).build()

        //Utilizar o Client criado para realizar a requisição e receber a resposta
        val response = client.newCall(request).execute()
        return response.body().toString()
    }
}