package br.com.gabriel.projetoxds

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import androidx.core.view.get

class EscolhaActivity : AppCompatActivity() {
    lateinit var srcPizza : SearchView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_escolha)
        srcPizza = findViewById(R.id.SrcPizza)
    }

    fun lytPizza4Queijos(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza","4queijos")
        startActivity(it)
    }

    fun lytPizzaToscana(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "toscana")
        startActivity(it)
    }
    fun lytPizzaAtum(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "atum")

        startActivity(it)
    }
    fun lytPizzaPortuguesa(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "portuguesa")
        startActivity(it)
    }
    fun LytPizzaMarguerita(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "marguerita")
        startActivity(it)
    }
    fun LytPizzaPeperoni(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "peperoni")
        startActivity(it)
    }

    fun LytPizzaCalabresa(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "calabresa")
        startActivity(it)
    }
    fun LytPizzaMussarela(view: View) {
        val it = Intent(this, DetalheActivity :: class.java)
        it.putExtra("pizza", "mussarela")
        startActivity(it)
    }
}