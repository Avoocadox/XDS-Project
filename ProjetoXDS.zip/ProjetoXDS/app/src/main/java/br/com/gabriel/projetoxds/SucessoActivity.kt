package br.com.gabriel.projetoxds

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import br.com.gabriel.projetoxds.R

class SucessoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sucesso)
    }

    fun btnVoltar(view: View) {
        val it = Intent(this, EscolhaActivity :: class.java)
        startActivity(it)
    }
}